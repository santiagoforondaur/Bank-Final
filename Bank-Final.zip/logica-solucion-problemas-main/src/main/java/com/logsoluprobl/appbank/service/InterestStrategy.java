package com.logsoluprobl.appbank.service;

public interface InterestStrategy {
    double calculateInterest(double balance);
}
